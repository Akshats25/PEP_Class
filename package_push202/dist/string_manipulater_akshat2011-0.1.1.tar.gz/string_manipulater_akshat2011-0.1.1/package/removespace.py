def remove_spaces(s):
    return s.replace(" ",",")