from saint import help_menu,remove_char,remove_html_char

a = remove_html_char("")
help_menu()