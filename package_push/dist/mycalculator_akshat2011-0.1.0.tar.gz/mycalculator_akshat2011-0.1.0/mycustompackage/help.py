def help_info():
    print("This is help. You are being helped...")